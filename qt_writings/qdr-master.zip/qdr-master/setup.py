from setuptools import find_packages, setupsetup(
    name='qdr',
    packages=find_packages(),
    version='0.1.0',
    description='Queer Distant Reading',
    author='Filipa',
    license='Attribution 2.0 Generic (CC BY 2.0) Y',
)

# need to install NLTK